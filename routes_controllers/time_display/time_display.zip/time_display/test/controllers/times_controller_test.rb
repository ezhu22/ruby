require 'test_helper'

class TimesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
