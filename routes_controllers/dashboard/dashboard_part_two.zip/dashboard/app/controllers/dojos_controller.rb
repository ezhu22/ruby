class DojosController < ApplicationController
    def index
        @dojos = Dojo.all.select('branch','street','city','state')
        @num_of_dojo = Dojo.count
    end

    def new
    end

    def create
        @dojo = Dojo.create(branch: params[:branch], street: params[:street], city: params[:city], state: params[:state])
        if @dojo.valid?
            flash[:success] = "Entered New Dojo Successfully."
            redirect_to '/dojos/index'
        else
            flash[:error] = "You did not enter in the information correctly."
            redirect_to '/dojos/new'
        end
    end
end
