class DojosController < ApplicationController
    def index
        @dojos = Dojo.all.select('id','branch','street','city','state')
        @num_of_dojo = Dojo.count
    end

    def new
    end

    def create
        @dojo = Dojo.create(branch: params[:branch], street: params[:street], city: params[:city], state: params[:state])
        if @dojo.valid?
            flash[:success] = "Entered New Dojo Successfully."
            redirect_to '/dojos/index'
        else
            flash[:error] = "You did not enter in the information correctly."
            redirect_to '/dojos/new'
        end
    end

    def show
        if params[:id] == 'index'
            redirect_to '/'
        else
            @dojo = Dojo.find(params[:id])
        end
    end

    def edit
        @dojo = Dojo.find(params[:id])
    end

    def update
        @dojo = Dojo.find(params[:id])
        if params[:branch] != @dojo[:branch]
            @dojo.branch = params[:branch]
        end
        if params[:street] != @dojo[:street]
            @dojo.street = params[:street]
        end
        if params[:city] != @dojo[:city]
            @dojo.city = params[:city]
        end
        if params[:state] != @dojo[:state]
            @dojo.state = params[:state]
        end
        if @dojo.valid?
            @dojo.save
            flash[:success] = "Updated Dojo Successfully."
            redirect_to '/dojos/index'
        else
            flash[:error] = "You did not enter in the information correctly."
            redirect_to '/dojos/edit/<%= params[:id] %>'
        end
    end

    def delete
        @dojo = Dojo.find(params[:id]).destroy
        redirect_to '/'
    end

end
