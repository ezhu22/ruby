class DojosController < ApplicationController
  def index
    @dojo = Dojo.all.select('branch','street','city','state')
    @num_of_dojo = Dojo.count
  end

  def new
  end
end
