module RpgHelper
end
